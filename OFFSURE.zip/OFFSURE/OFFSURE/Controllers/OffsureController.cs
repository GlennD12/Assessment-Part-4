﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using OFFSURE.Data;
using OFFSURE.Models;

namespace OFFSURE.Controllers
{
    public class OffsureController : Controller
    {
        private readonly ApplicationDbContext _context;

        public OffsureController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Offsure
        public async Task<IActionResult> Index()
        {
              return _context.Offsure != null ? 
                          View(await _context.Offsure.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Offsure'  is null.");
        }

        public async Task<IActionResult> UserIndex()
        {
            return _context.Offsure != null ?
                        View(await _context.Offsure.ToListAsync()) :
                        Problem("Entity set 'ApplicationDbContext.Offsure'  is null.");
        }

        // GET: Offsure/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Offsure == null)
            {
                return NotFound();
            }

            var offsure = await _context.Offsure
                .FirstOrDefaultAsync(m => m.Id == id);
            if (offsure == null)
            {
                return NotFound();
            }

            return View(offsure);
        }

        // GET: Offsure/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Offsure/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Make,Model,Date,Apt,Price,Comments,Name,Phone_number,Email,Abn")] Offsure offsure)
        {
            if (ModelState.IsValid)
            {
                _context.Add(offsure);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(offsure);
        }

        // GET: Offsure/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Offsure == null)
            {
                return NotFound();
            }

            var offsure = await _context.Offsure.FindAsync(id);
            if (offsure == null)
            {
                return NotFound();
            }
            return View(offsure);
        }

        // POST: Offsure/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Make,Model,Date,Apt,Price,Comments,Name,Phone_number,Email,Abn")] Offsure offsure)
        {
            if (id != offsure.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(offsure);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OffsureExists(offsure.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(offsure);
        }

        // GET: Offsure/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Offsure == null)
            {
                return NotFound();
            }

            var offsure = await _context.Offsure
                .FirstOrDefaultAsync(m => m.Id == id);
            if (offsure == null)
            {
                return NotFound();
            }

            return View(offsure);
        }

        // POST: Offsure/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Offsure == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Offsure'  is null.");
            }
            var offsure = await _context.Offsure.FindAsync(id);
            if (offsure != null)
            {
                _context.Offsure.Remove(offsure);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OffsureExists(int id)
        {
          return (_context.Offsure?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
