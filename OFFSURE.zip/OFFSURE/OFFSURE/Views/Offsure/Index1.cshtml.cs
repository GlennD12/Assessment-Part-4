using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OFFSURE.Views.Offsure
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
