﻿namespace OFFSURE.Models
{
    public class Offsure
    {
        public int Id { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Date { get; set; }
        public string Apt { get; set; }
        public int Price { get; set; }
        public string Comments { get; set; }
        public string Name { get; set; }
        public string Phone_number { get; set; }
        public string Email { get; set; }
        public string Abn { get; set; }

        public Offsure()
        {

        }
    }
}
